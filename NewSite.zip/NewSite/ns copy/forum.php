<?php include "header.php" ?>
<html lang="en">

    <div class="sidenav white">
      <h1 class="topics">Topics</h1>
      <p class="bodyText option"><a class="white" href="#">Introductory Python</a></p>
      <p class="bodyText option"><a class="white" href="#">Introductory Java</a></p>
      <p class="bodyText option"><a class="white" href="#">Introductory C++</a></p>
      <p class="bodyText option"><a class="white" href="#">Data Structures</a></p>
      <p class="bodyText option"><a class="white" href="#">Basic Algorithms</a></p>
      <p class="bodyText option"><a class="white" href="#">Operating Systems</a></p>
      <p class="bodyText option"><a class="white" href="#">Computer Systems Organization</a></p>
      <p class="bodyText option"><a class="white" href="#">Machine Learning</a></p>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
